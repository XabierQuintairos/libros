package paagbi.librosxabi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgramaNagusia {

	public static void main(String[] args) {
		SpringApplication.run(ProgramaNagusia.class, args);
	}

}
